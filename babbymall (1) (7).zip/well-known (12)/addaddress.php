<?php 
ob_start();
session_start();
if($_SESSION['userid']=="")
{header("location:login.php");exit();}?>

<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<?php include'head.php' ?>

<link rel="stylesheet" href="assets/css/style.css">

<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
<meta name="description" content="Bitter Mobile Template">
<meta name="keywords" content="bootstrap, mobile template, bootstrap 4, mobile, html, responsive" />
<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet"/>
<link href="assets/css/dataTables.bootstrap.min.css" rel="stylesheet"/>
<style>
.btn { 
  width:264px;font-size:16px; height:44px;color:white;
    
}

.form-control{box-shadow:none; border-bottom:#ccc solid 1px; height:26px; margin-bottom:3px;}
.form-group{margin-bottom:0px;}
.form-group.>label {
    bottom: 34px;
    left: 8px;
    position: relative;
    background-color: white;
    padding: 0px 5px 0px 5px;
    font-size: 1.1em;
    transition: 0.1s;
    pointer-events: none;
    font-weight: 500 !important;
    transform-origin: bottom left;
}

.form-control.:focus~label{
    transform: translate(1px,-85%) scale(0.80);
    opacity: .8;
    color: #005ebf;
}

.form-control.:valid~label{
    transform-origin: bottom left;
    transform: translate(1px,-110%) scale(0.80);
    opacity: .8;
}
.appContent1{
width: 100%;
    padding: 15px 15px 64px 15px;
    box-sizing: border-box;
}
.textarea{
    background: transparent;
    font-size: 16px;
    border: 0;
    border-bottom: 1px solid #919191;
   
}

label{
    padding-top:10px;
}
.btnn{
    width: 65%;
    padding: 12px 0;
    text-align: center;
    border: 0;
    border-radius: 2px;
    color: #fff;
    font-size: 14px;
    background: #009688;
    box-shadow: 0 3px 1px -2px rgb(0 0 0 / 20%), 0 2px 2px 0 rgb(0 0 0 / 14%), 0 1px 5px 0 rgb(0 0 0 / 12%);

}
label{
    color:#7d7d7d;
    font-weight:400;
    font-size:14px;
}
</style>
</head>

<body>
<?php 
include("include/connection.php");
$userid=$_SESSION['userid'];?>
<!-- Page loading -->

<!-- * Page loading --> 

<!-- App Header -->
<div class="appHeader1">
  <div class="left"> <a href="/address.php" onClick="goBack();" class="icon goBack"> <i class="icon ion-md-arrow-back"></i> </a>
    <div class="pageTitle">Add Address</div>
  </div>
</div>
<!-- searchBox --> 

<!-- * searchBox --> 
<!-- * App Header --> 

<!-- App Capsule -->
<div id="appCapsule">
  <div class="appContent1" style="margin-top:-25px;">
    <form action="#" method="post" id="addresscardform">
      
      <div class="form-group floating mt-3">
          <label for="name">Full Name</label>
<input type="text" class="form-control floating textarea" id="name" name="name" required value="">

</div>
<div class="form-group floating">
    <label for="mobile">Mobile Number</label>
<input type="number" class="form-control floating textarea" id="mobile" name="mobile" required value="">

</div>
<div class="form-group floating">
    <label for="pincode">Pincode</label>
<input type="number" class="form-control floating textarea" id="pincode" name="pincode" required value="">

</div>
<div class="form-group floating">
    <label for="state">State</label>
<input type="text" class="form-control floating textarea" id="state" name="state" required value="">

</div>

<div class="form-group floating">
    <label for="city">Town/City</label>
<input type="text" class="form-control floating textarea" id="city" name="city" required value="">

</div><div class="form-group floating">
    <label for="address">Detail Address</label>
<input type="text" class="form-control floating textarea" id="address" name="address" required value="">

</div>


<input type="hidden" name="action" value="bank">
<input type="hidden" name="userid" value="<?php echo $userid;?>">
<input type="hidden" name="editid" value="">
<div class="text-center mt-3">
        <button type="submit" class="btnn"> Continue </button>
      </div>
    </form>
  </div>
</div>
<!-- appCapsule -->

<?php include("include/footer.php");?>
<div id="alert" class="modal fade" role="dialog">
  <div class="modal-dialog modal-sm" role="document">
    <div class="modal-content">
      <div class="modal-body" id="alertmessage"> </div>
      <div class="text-center pb-1">
    <a type="button" class="text-info" data-dismiss="modal"><a href="address.php" style="colour: black;">OK</a></a>
    </div> 
    </div>
  </div>
</div>
<!-- Jquery --> 
<script src="assets/js/lib/jquery-3.4.1.min.js"></script> 
<!-- Bootstrap--> 
<script src="assets/js/lib/popper.min.js"></script> 
<script src="assets/js/lib/bootstrap.min.js"></script> 
<!-- Owl Carousel --> 
<script src="assets/js/plugins/owl.carousel.min.js"></script> 
<!-- Main Js File --> 
<script src="assets/js/app.js"></script>
<script src="assets/js/addaddress.js"></script>
</body>
</html>