<?php 
ob_start();
session_start();
if($_SESSION['userid']=="")
{header("location:login.php");exit();}?>

<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<?php include'head.php' ?>

<link rel="stylesheet" href="assets/css/style.css">
<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
<meta name="description" content="Bitter Mobile Template">
<meta name="keywords" content="bootstrap, mobile template, bootstrap 4, mobile, html, responsive" />
<style>

.card {
    border: 1px solid #E5E9F2;
    border-radius: 3px;
    padding: 0px;
}
.card .card-title {
    margin-bottom: 7px;
}
.card-body{ padding:.6rem;}
td{ padding:3px;}
.btn-sm {
    height: 26px;
    padding: 0px 12px;
}
#confirm h4{font-size: 1rem;}
#confirm p{font-size: 13px; margin-top:20px;}
#confirm .modal-content{border-radius:3px}
#confirm .modal-dialog{padding:20px; margin-top:130px;}
.imga{height:25px;width:25px;}
</style>
</head>

<body>
<?php
include("include/connection.php");
$userid=$_SESSION['userid'];?>

<!-- * Page loading --> 

<!-- App Header -->
<div class="appHeader1" >
  <div class="left"> <a href="/mine.php" onClick="goBack();" class="icon goBack"> <i class="icon ion-md-arrow-back"></i> </a>
    <div class="pageTitle" >Address</div>
  </div>
  
  <div class="right"> 
  <a class="" href="addaddress.php" role="button" style="font-size:20px; color: white;">
    <img class="imga" src="images/plus.png"></a>
</div>
  </div>
<!-- searchBox --> 

<!-- * searchBox --> 
<!-- * App Header --> 

<!-- App Capsule -->
<div id="appCapsule" class="pb-2">
  <div class="appContent1 pb-5">
   
      <div class="mt-1">
      <div class="tab-content" id="myTabContent">
      <!--=========================tab-1========================================-->
        <div class="tab-pane fade active show" id="bank" role="tabpanel">
          
       
        <?php
$selectBankQuery=mysqli_query($con,"select * from `tbl_address` where `userid`='".$userid."'");
$bankRows=mysqli_num_rows($selectBankQuery);
if($bankRows!=''){
while($bankResult=mysqli_fetch_array($selectBankQuery)){
		?>
        <div class="card mb-3">
                <div class="card-body">
                   
                    <h6><?php echo $bankResult['name'];?></h6>
                    <p class="text-primary"><strong><?php echo $bankResult['mobile'];?></strong></p>
                    <p><?php echo $bankResult['address'];?>, <?php echo $bankResult['city'];?>, <?php echo $bankResult['state'];?>, <?php echo $bankResult['pincode'];?></p>
                    
                    
                </div>
            </div>
            
<?php }}?>
        </div>

        </div>

        </div>
      </div>
  </div>

<!-- appCapsule -->

<?php include("include/footer.php");?>
<!-- Jquery --> 
<script src="assets/js/lib/jquery-3.4.1.min.js"></script> 
<!-- Bootstrap--> 
<script src="assets/js/lib/popper.min.js"></script> 
<script src="assets/js/lib/bootstrap.min.js"></script> 
<!-- Owl Carousel --> 
<script src="assets/js/plugins/owl.carousel.min.js"></script> 
<!-- Main Js File --> 
<script src="assets/js/app.js"></script>

</body>

</html>